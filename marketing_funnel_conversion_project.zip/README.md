# Marketing Funnel & Conversion Performance Analysis

**Data Science & Analytics – Task 3 (2026)**  
**By Future Interns**

## Project Overview

This project analyzes a simulated SaaS-style marketing funnel to understand how users move from:

**Visitors → Leads → MQLs → SQLs → Trials → Customers**

The analysis identifies where users drop off, which channels produce high-quality leads, which campaigns perform best, and what practical actions can improve lead-to-customer conversion.

## Business Problem

A subscription-based business wants to improve marketing efficiency and increase revenue by answering:

- Where are users dropping off in the funnel?
- Which channels bring high-quality leads?
- Which campaigns convert best?
- How can conversion rates be improved?
- Which funnel stages need optimization?

## Dataset

The dataset is a clean simulated marketing funnel dataset covering **January to June 2026**.

It includes daily performance by:

- Date and month
- Marketing channel
- Campaign
- Region
- Device
- Audience segment
- Ad spend
- Visitors
- Leads
- MQLs
- SQLs
- Trials
- Customers
- Revenue

> Note: The data is simulated for project purposes but designed to reflect a realistic marketing analytics scenario.

## Tools Used

- Microsoft Excel
- Data cleaning and structuring
- Funnel analysis
- Conversion metrics
- Channel and campaign performance analysis
- Dashboard design
- Business reporting

## Key Metrics

| Metric | Value |
|---|---:|
| Total Visitors | 108,405 |
| Total Leads | 7,553 |
| Total Customers | 531 |
| Total Revenue | $319,576 |
| Total Ad Spend | $59,680 |
| Traffic-to-Lead Conversion | 6.97% |
| Lead-to-Customer Conversion | 7.03% |
| Customer Acquisition Cost | $112.39 |
| ROAS | 5.35x |

## Main Insights

1. The largest funnel drop-off happens at **Visitors → Leads**, with a **93.0%** drop-off rate.
2. **Referral** has the strongest lead-to-customer conversion.
3. **Social Media** has the weakest lead-to-customer conversion and needs targeting and lead-quality improvements.
4. **Email** delivers the strongest ROAS, making it a strong channel for controlled budget scaling.
5. Middle-funnel stages need better lead qualification, faster follow-up, and stronger trial onboarding.

## Recommendations

- Improve landing pages and simplify lead forms to increase traffic-to-lead conversion.
- Scale high-performing channels while monitoring CAC and sales capacity.
- Reduce budget waste in low-ROAS campaigns until targeting improves.
- Build separate nurture flows by channel and customer intent level.
- Improve lead scoring to prioritize high-quality leads.
- Optimize trial onboarding to improve trial-to-customer conversion.

## Files Included

| File | Description |
|---|---|
| `marketing_funnel_conversion_analysis.xlsx` | Excel workbook with dashboard, formulas, charts, and analysis sheets |
| `marketing_funnel_conversion_report.pdf` | Executive report with insights and recommendations |
| `marketing_funnel_conversion_dataset_simulated.csv` | Clean simulated dataset |
| `marketing_dashboard_preview.png` | Dashboard preview image |
| `README.md` | GitHub documentation |

## How to Use This Project

1. Open the Excel workbook.
2. Review the `Dashboard` sheet for the executive summary.
3. Check `Funnel_Analysis` for stage-by-stage drop-off.
4. Check `Channel_Performance` and `Campaign_Performance` for growth opportunities.
5. Read the PDF report for stakeholder-ready insights.

## Suggested LinkedIn Post

I completed a Marketing Funnel & Conversion Performance Analysis project as part of Future Interns Data Science & Analytics Task 3.

In this project, I analyzed funnel data to understand how users move from visitors to leads, qualified leads, trials, and paying customers.

Key outcomes:
- Identified the largest conversion drop-off stage.
- Compared channel and campaign performance.
- Calculated traffic-to-lead and lead-to-customer conversion rates.
- Built an Excel dashboard and stakeholder-ready report.
- Created actionable recommendations to improve conversions.

Tools used: Excel, funnel analysis, conversion metrics, dashboard design, and business reporting.

#DataAnalytics #MarketingAnalytics #FunnelAnalysis #ConversionOptimization #FutureInterns #DataScience
